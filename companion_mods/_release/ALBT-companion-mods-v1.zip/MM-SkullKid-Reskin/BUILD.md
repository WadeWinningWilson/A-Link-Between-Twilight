# MM Skull Kid Reskin — build steps (v1: textures only, Layer B)

Gitignored companion mod. Requires Dusklight build with `daE_PM_c` Layer-B hook (2026-06-19).

## Mod layout (no arc repack)

```
MM-SkullKid-Reskin/
  modinfo.ini
  E_PM_29.bmd    ← body  (arc index 0x1D) — required for v1
  E_PM_30.bmd    ← lamp  (0x1E) — optional
  E_PM_31.bmd    ← trumpet (0x1F) — optional
  E_PM_28.bmd    ← glow FX mesh (0x1C) — optional
```

Install: copy folder → `%AppData%\TwilitRealm\Dusklight\model_replacements\MM-SkullKid-Reskin\`

Enable in **Editor → ALBW → Custom Models**. Missing files fall back to vanilla arc resources.

## Vanilla source BMD

Extract from:

`D:\Decomps\Dusk Mods\Extracted ISO\files\res\Object\E_pm.arc`

Use `tools/companion_mod/extract_rarc.py` or SuperBMD/GCFT. Body = resource **0x1D**.

## Retexture workflow

**Do not run SuperBMD on raw arc extracts** — TP `E_pm` body/lamp/trumpet are BMDR blobs without a `J3D2` header and SuperBMD will reject them.

### Step 0 — Export from in-game (Layer C, dev)

1. Build Dusklight with the `bmd_export` module (included in current tree).
2. Load **Sacred Grove** so Skull Kid / `E_PM` is resident.
3. **Debug → BMD Export (dev)** → export body (0x1D), lamp (0x1E), trumpet (0x1F).
4. Output lands under `%AppData%\TwilitRealm\Dusklight\bmd_export\`:
   - `E_PM_29_EDITABLE.bmd` — J3D2 dump with PC endian restore applied (SuperBMD-ready)
   - `E_PM_29_EDITABLE_export_report.txt` — joints/shapes/materials/vertex counts + raw magic
   - `E_PM_29_EDITABLE_textures/` — embedded BTI reference dumps for texture painting

If export is **diagnostic-only** (no J3D2 in `mpRawData`), use the report + texture refs for reference; a future memory→bmd3 serializer may be needed for a full SuperBMD round-trip on BMDR-only assets.

### Step 1 — Extract MM `object_stk` (MM-native names only)

```powershell
python tools/companion_mod/mm_extract_object_stk.py
```

Output: `companion_mods/MM-SkullKid-Reskin/_work/object_stk/`

This is **not** a 1:1 swap with TP `pm_*.png`. MM and TP Skull Kid use different meshes/submeshes (TP has lamp/trumpet; MM has flute/mask in `object_stk` but grove v1 body does not require them).

Review `TEXTURE_REVIEW.md` + `n64_preview8x/*.png`. Confirm MM-native names (`skull_kid_skin`, etc.).

### Step 2 — Paint MM look onto TP UV templates

Use `textures_vanilla/` as the canvas (TP `pm_tex01`, `pm_leaf01`, `pm_eye.1` at fixed sizes). Reference MM art from `_work/object_stk/` or MMN64HD picks in `hd/`.

Save result as `textures_mm/` → Blender: `python tools/blender_socket/mm_skullkid_blender_textures.py --mm`

### Step 3 — SuperBMD / Blender (mesh unchanged)

**Blender handoff (socket port 9876):** [`docs/Blender-MM-SkullKid.md`](../../docs/Blender-MM-SkullKid.md)  
Working blend: `D:\Decomps\Ex TP\Blender workflow\Custom porting work\MM\MM_SkullKid_v1.blend` (body imported 2026-07-16).

**SuperBMD staging folder:** `D:\Decomps\Ex TP\Blender workflow\Custom porting work\MM\superbmd_out\`

**Status (2026-07-16):** In-game export now runs **endian restore** (VTX1/JNT1/SHP1) before write. SuperBMD v2.4.9.0 converts body successfully. Offline fallback: `tools/companion_mod/unfix_bmd_pc_endian.py`.

**SuperBMD note:** omit `--outmat` (SuperBMD 2.4.9 passes the materials directory to `FileStream` by mistake). Default output is `<input_stem>_materials.json` beside the DAE.

**Blender version (when SuperBMD works):** **4.2 LTS** for Collada import/export. Fallback: **3.6 LTS** if Collada is flaky. Do not use Blender 5.x for the DAE bridge (Collada removed). SuperBMD itself is version-independent.

1. SuperBMD: exported `E_PM_29_EDITABLE.bmd` → DAE (keep skeleton untouched for v1).
2. MM reference: Zelda64Recompiled + HD texture pack (local install).
3. Swap material PNGs in Blender — **textures only**, no bone/mesh edits.
4. SuperBMD back with **`-m`** materials JSON (input — use `E_PM_29_EDITABLE_materials.json` from `superbmd_verify`). Do not use `--outmat` on BMD→DAE.
5. Rename/deploy as `E_PM_29.bmd` in this folder → playtest Sacred Grove.

If you edit mesh/bones, run [`tools/bmd_reskin/bmd_reskin.py`](../../tools/bmd_reskin/bmd_reskin.py) before deploy.

## Removability

Disable mod in Custom Models or delete the folder → vanilla Skull Kid returns. No arc file needed.
